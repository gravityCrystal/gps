from common.database import Database
from models.blog import Blog


class Menu(object):
    def __init__(self):
        # ask for author name
        # check if they already have account
        # if not prompt to create one
        self.user = input("Enter the author name")
        if self._user_has_account():
            print("Welcome back {}".format(self.user))
            self.show_menu()
        else:
            self._prompt_user_for_account()
            
    def _user_has_account(self):
        blog = Database.findOne('blogs', {'author': self.user})
        print(blog)
        if blog is not None:
            self.user_blog = Blog.get_from_mongo(blog['_id'])
            return True
        else:
            return False
        
    def _prompt_user_for_account(self):
        title= input('Enter blog title')
        description = input("Enter the description")
        blog = Blog(author = self.user,
                    title=title,
                    description= description)
        blog.save_blog_to_mongo()
        self.user_blog = blog
    
    def show_menu(self):
#         read or write a input 
#         read_or_write = input(" Do you want to read(r) or write(w) blogs?")
#         if read_or_write == 'r':
#             # read a blog
#             self._list_blog()
#             self._view_blog()
#         elif read_or_write == 'w':
#             # write a new blog
#             self._prompt_write_blog()
#         else:
#             print("Thanks for blogging !!")
        read_or_write_menu = True
        while read_or_write_menu:
            print("""
            1.Read a Blog
            2.Write a new Blog
            3.Exit/Quit
            """)
            read_or_write_menu=input("What would you like to do? ")
 
            if read_or_write_menu=="1":
                print("\n Read a Blog")
                self._list_blog()
                self._view_blog()
            elif read_or_write_menu=="2":
                print("\n Write a new Blog")
                self._prompt_write_blog()
            elif read_or_write_menu=="4":
                print("\n Goodbye") 
                read_or_write_menu = None
            else:
                print('Not a menu option')

    
    def _prompt_write_blog(self):
        self.user_blog.new_post()
        
    def _list_blog(self):
        blogs = Database.find(collection='blogs', query={})
        for blog in blogs:
            print("ID:{}, Title: {}, Author: {}".format(blog['_id'], blog['title'], blog['author']))
            
    def _view_blog(self):
        blog_to_see = input("Enter the blog that you would like to see")
        blog = Blog.get_from_mongo(blog_to_see)
#         print(blog)
        posts = blog.get_posts()
#         print("All post as follows")
        for post in posts:
            print("Date: {}, title: {}\n\n{}".format(post['created_date'], post['title'], post['content']))
        