from LinkedList.LinkedLst import LinkedList


ll  = LinkedList()
ll.insertAtFirst(12)
ll.insertAtLast(123)
ll.insertAtFirst(124)
ll.insertAtLast(125)
ll.insertAtFirst(121)
ll.insertAtLast(120)


ll.traverseList()

print('-------------------------------')
ll.remove(12)
print('-------------------------------')
ll.traverseList()

print('-------------------------------')

ll.size()