from math import pi,sqrt,sin,cos,atan2

def haversine(pos1, pos2):
    print(pos1,pos2);
    lat1 = float(pos1['lat'])
    long1 = float(pos1['long'])
    lat2 = float(pos2['lat'])
    long2 = float(pos2['long'])

    degree_to_rad = float(pi / 180.0)

    d_lat = (lat2 - lat1) * degree_to_rad
    d_long = (long2 - long1) * degree_to_rad

    a = pow(sin(d_lat / 2), 2) + cos(lat1 * degree_to_rad) * cos(lat2 * degree_to_rad) * pow(sin(d_long / 2), 2)
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    km = 6367 * c
    mi = 3956 * c
    print(km, mi)
    return {"km":km, "miles":mi}

pos1={'lat':51.5,'long': 0};
pos2 = {'lat':38.8,'long':-77.1}
