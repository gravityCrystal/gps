# age = input('Please enter your age');
# age = int(age) * 24 * 365 * 3600
# print('Age in {} seconds'.format(age));


def age_prg():
    choice = input('Give me input in years(y)/seconds(s)')
    if choice == 's':
        age = input('Enter age in years')
        sec = int(age) * 24 *365 * 3600
        print('your age is {sec} seconds'.format(sec=sec))
    elif choice =='y':
        yrs = input('Enter age in seconds 0')
        yrs = int(yrs)/(24*365*3600)
        print('your age is {} years'.format(yrs))
        
age_prg();