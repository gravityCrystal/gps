import heapq

class Dijkstra(object):
    def calculateShortestPath(self, vertexList, startV):
        queue= []
        startV.minDistance = 0
        heapq.heappush(queue, startV)
        
        
        while len(queue) > 0:
            actualV = heapq.heappop(queue)
            
            for edge in actualV.adjacentList:
                u = edge.startV
                v= edge.targetV
                newDistance = u.minDistance + edge.weight
                
                if newDistance < v.minDistance:
                    v.predecessor = u;
                    v.minDistance = newDistance
                    heapq.heappush(queue, v)
                    
    def getShortestDisatnce(self, targetV):
        print(" Shortest path to target vertex is:", targetV.minDistance)
        node = targetV
        while node is not None:
            print(" - >", node.name)
            node = node.predecessor