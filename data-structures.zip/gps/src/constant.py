#coordinates of Dublin
originCoordinate = {'latitude': 53.339428, 'longitude': -6.257664}