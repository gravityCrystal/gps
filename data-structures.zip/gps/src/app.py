# from readfile import readGpsData
# from haverineAlgo import haversine
# import constant
# 
# 
# print(constant.originCoordinate)
# data = readGpsData()
# 
# for i in data:
#     print(i)
# # print(data)