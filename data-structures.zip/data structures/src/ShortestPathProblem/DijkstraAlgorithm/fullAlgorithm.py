import sys
import heapq
class Vertex(object):
    def __init__(self,name):
        self.name = name
        self.visited = False
        self.predecessor = None
        self.adjacentList=[]
        self.minDistance = sys.maxsize
        
    def __cmp__(self, otherVertex):
        return self.cmp(self.minDistance, otherVertex.minDistance)
    
    def __lt__(self, other):
        selfPriority = self.minDistance
        otherPriority = other.minDistance
        return selfPriority < otherPriority
    
class Edge(object):
    def __init__(self, weight, startV, targetV):
        self.weight = weight
        self.startV = startV
        self.targetV = targetV
        


class Dijkstra(object):
    def calculateShortestPath(self, vertexList, startV):
        queue= []
        startV.minDistance = 0
        heapq.heappush(queue, startV)
        
        
        while len(queue) > 0:
            actualV = heapq.heappop(queue)
            
            for edge in actualV.adjacentList:
                u = edge.startV
                v= edge.targetV
                newDistance = u.minDistance + edge.weight
                
                if newDistance < v.minDistance:
                    v.predecessor = u;
                    v.minDistance = newDistance
                    heapq.heappush(queue, v)
                    
    def getShortestDisatnce(self, targetV):
        print(" Shortest path to target vertex is:", targetV.minDistance)
        node = targetV
        while node is not None:
            print(" - >", node.name)
            node = node.predecessor
            
            
            
node1 = Vertex("A")
node2 = Vertex("B")
node3 = Vertex("C")
node4 = Vertex("D")


edge1 = Edge(1, node1, node2)
edge2 = Edge(1, node2, node3)
edge3 = Edge(0.2, node1, node3)
edge4 = Edge(0.1, node1, node4)

node1.adjacentList.append(edge1)
node1.adjacentList.append(edge2)
node2.adjacentList.append(edge3)
node1.adjacentList.append(edge4)

vertexList =[node1, node2, node3, node4]

djt = Dijkstra()
djt.calculateShortestPath(vertexList, node1)
djt.getShortestDisatnce(node4)
