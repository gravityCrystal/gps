package BFS;
import java.util.ArrayList;
import java.util.List;

public class ertex {
	
	private int data;
	private boolean visited;
	private List<Vertex> neighourList;
	
	public Vertex(int data) {
		this.data = data;
		this.neighbourList =  new Array<>();
	}
	
	public void addNeighbour(Vertex vertex ){
		this.neighbourList.add(vertex);
	}
	
	
	
}