from models.post import Post
from common.database import Database
from models.blog import Blog
from models.menu import Menu

Database.initalize()
# 
# 
# # 
post = Post(blog_id ="122",
            title='Header4',
            content='Hello hi Ankur hi  there',
            author="Ankur");
             
# # post2 = Post();a
# # post3  = Post("10000","title", "content", "author", "6467686", "15/06/2019")

# # print(post.content)

# post.save_to_mongo();
 
# post = post.all_post() 
# post = post.from_mongo('c5abe4e3592f403eba1b3f5b5602a306')
# post = Post.from_post("125")
# print(post)


blog = Blog(author="Ankur",
            title="title",
            description= "sample description")
# 
# blog.new_post()
# blog.save_blog_to_mongo()
# from_db = blog.get_from_mongo("56a7422834e54b259757dbb8c2f8a3da")
# print(from_db)

# print(blog.get_posts("fa5c5c8f3ff54881b069a1ad545c1ca1"))

# print(blog.get_all_posts())
menu = Menu()
# menu.show_menu()
