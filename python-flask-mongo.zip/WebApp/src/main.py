from models.user import User
from models.blog import Blog
from models.post import Post

from flask import Flask, render_template, request, session
from common.database import Database
from flask.helpers import make_response

app = Flask(__name__) # '__main__'

app.secret_key="qweqw1231123"

@app.route('/') # new end point
def home():
#     return render_template('home.html')
    return make_response(blogs_post('16180165363344afbec91b2e5928c09e'))

@app.route('/login') # new end point
def go_login():
    return render_template('login.html')

@app.route('/register') # new end point
def go_register():
    return render_template('register.html')

@app.before_first_request
def intialize_DB():
    Database.initalize()

@app.route('/auth/login', methods = ['GET', 'POST'])
def login_user():
    email= request.form['email'];
    password = request.form['password']
    if User.login_valid(email, password):
        User.login(email)
    else:
        session['email'] = None
        
    return render_template("profile.html", email = session['email'])

@app.route('/auth/register', methods=[ 'POST'])
def register_user():
    email = request.form['email']
    password = request.form['password']
    
    User.register(email, password)
    return render_template('profile.html', email = session['email'])


@app.route('/blog/<user_id>', methods= ['POST'])
@app.route('/blogs')
def user_blogs(user_id = None):
    if user_id is not None:
        user = User.get_by_id(user_id)
    else:
        user = User.get_by_email(session['email'])
        
    blogs = user.get_blogs()
    return render_template('user_blogs.html', blogs = blogs, email = session['email'])



@app.route('/posts/<blog_id>', methods= ['POST'])
def blogs_post(blog_id):
    blog = Blog.get_from_mongo(blog_id)
    print(blog,"-------")
    posts= blog.get_posts()
    
    return render_template('posts.html', posts=posts, blog_name = blog.title, blog_id = blog._id )


@app.route('/blogs/new', methods = ['GET','POST'])
def create_new_blog():
    if  request.method == 'GET':
        return render_template('newblogs.html')
    else:
        title = request.form['title']
        content = request.form['description']
        user = User.get_by_email(session['email'])
        
    new_blog = Blog(user.email,title,content, user._id)
    new_blog.save_blog_to_mongo()
    
    return make_response(user_blogs(user._id))


@app.route('/posts/new/<blog_id>', methods = ['GET','POST'])
def create_new_post(blog_id):
    if  request.method == 'GET':
        return render_template('newpost.html')
    else:
        title = request.form['title']
        content = request.form['content']
        user = User.get_by_email(session['email'])
         
    new_post = Post(user.email,title,content, blog_id)
    new_post.save_blog_to_mongo()
     
    return make_response(blogs_post(blog_id))


@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html')

if __name__ == "__main__":
    app.run(port = 4500, debug=True, use_reloader=True)