from database import Database
import uuid
import datetime


class Post(object):
    
    def __init__(self, blog_id, title, content, author, date = datetime.datetime.utcnow(), uid = None):
        self.title= title
        self.content = content
        self.author = author
        self.blog_id = blog_id
        self.id = uuid.uuid4().hex if uid is None else uid
        self.created_date = date
        
    def save_to_mongo(self):
        Database.insert(collection='posts', data = self.json())
#             pass
    
    def json(self):
        return {
            'id': self.id,
            'blog_id': self.blog_id,
            'author': self.author,
            'content': self.content,
            'title': self.title,
            'created_date': self.created_date
            }
    @classmethod
    def from_mongo(cls, uid):
        post_data = Database.findOne(collection ='posts', query= { 'id':uid })
        return cls(blog_id = post_data['blog_id'],
                   title = post_data['title'],
                   content = post_data['content'],
                   author = post_data['author'],
                   date = post_data['created_date'],
                   id = post_data['id'] )
    
    
    @staticmethod
    def from_blog(uid):
        return [pos for pos in Database.find(collection= "posts", query= { 'blog_id' : uid })]
    
    
    @staticmethod
    def from_post(uid):
        return [pos for pos in Database.find(collection= "posts", query= { 'blog_id' : uid })]
   
    
    @staticmethod
    def all_post():
        return  [pos for pos in Database.find(collection= "posts", query= {})]