
# def readGpsData():
f=open("data.txt", "r")
ll=[]
if f.mode == 'r':
#     contents = f.read()
    l = f.readlines() 
#     print(l)
    for x in l:
        ll.append(x)
#     for key, value in l:
#         print (key, value)
#   
  
#   return contents
#    
print(ll)
# readGpsData()