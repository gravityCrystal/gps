import pymongo


uri ="mongodb://127.0.0.1:27017"
client = pymongo.MongoClient(uri)
database = client['fullstack']
collection =  database['posts']
students = collection.find()

# first way to call students
# student_list =[]
# for student in students:
#     print(student)
     
#      second way to call
# students = [student for student in collection.find() if student['mark'] < 100]    

students = [student for student in collection.find()]    
# # list compreshension    
print(students)
#     
