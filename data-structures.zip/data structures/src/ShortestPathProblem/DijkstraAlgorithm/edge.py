class Edge(object):
    def __init__(self, weight, startV, targetV):
        self.weight = weight
        self.startV = startV
        self.targetV = targetV