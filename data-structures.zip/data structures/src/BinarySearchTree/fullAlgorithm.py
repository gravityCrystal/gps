class Node(object):
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
       
        
    def insert(self,data):
        if data < self.data:
            if not self.left:
                self.left= Node(data)
            else:
                self.left.insert(data)
        else:
            if not self.right:
                self.right  = Node(data)
            else:
                self.right.insert(data)
    
    def getMin(self):
        if self.left is None:
            print(self.data)
            return self.data
        else:
            self.left.getMin()
    
    def getMax(self):
        if self.right is None:
            print(self.data)
            return (self.data)
        else:
            self.right.getMax()
            
    def traverseList(self):
        if self.left is not None:
            self.left.traverseList()
        
        print('In order Traversal','--->',self.data)
        if self.right is not None:
            self.right.traverseList()
            
    def remove(self, data, parent):
        if (data < self.data):
            if self.left is not None:
                self.left.remove(data, self)
        elif (data > self.data):
            if self.right is not None:
                self.right.remove(data, self)
        
        else:
            if self.left is not None and self.right is not None:
                self.data = self.right.getMin()
                self.right.remove(self.data, self)
                
            elif parent.left == self:
                if self.left is not None:
                    temp = self.left
                else:
                    temp = self.right
                parent.left = temp
            
            elif parent.right == self:
                if self.left is not None:
                    temp = self.left
                else:
                    temp = self.right
                parent.right = temp    
                
                
class BST(object):
    def __init__(self):
        self.root = None
        
    
    def insert(self, data):
        if not self.root:
            self.root = Node(data)
        else:
            self.root.insert(data);
            
    def remove(self, dataToRemove):
        if self.root:
            if self.root.data == dataToRemove:
                temp = Node(None)
                temp.left = self.root
                self.root.remove(dataToRemove, temp)
            else:
                self.root.remove(dataToRemove, None)
                
    
    def getMax(self):
        if self.root:
            return self.root.getMax()
        
    
    def getMin(self):
        if self.root:
            return self.root.getMin()
        
    def traverseListInOrder(self):
        if self.root:
            self.root.traverseList()
            


bst = BST()

bst.insert(12)

bst.insert(-123)

bst.insert(124)

bst.insert(26)

bst.insert(129)
bst.traverseListInOrder()

print(bst.getMax())

print(bst.getMin())
bst.remove(26)
bst.remove(12)
bst.traverseListInOrder()
                