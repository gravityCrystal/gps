class Bellmanford(object):
    HAS_CYCYLE= False
    
    def calculateShortestPath(self , vertextList, edgeList, startVertex):
        startVertex.minDistance = 0
        
        for i in range(0, len(vertextList)-1):
            for edge in edgeList:
                
                u = edge.startVertex
                v = edge.targetVertex
                newDistance = u.minDistance  + edge.weight
                
                if newDistance < v.minDistance:
                    v.minDistance = newDistance
                    v.predecessor = u
                    
            for edge in edgeList:
                if self.hasCycle(edge):
                    print("Negative cycle detected")
                    Bellmanford.HAS_CYCYLE = True
                    return;
                
    def hasCycle(self, edge):
        if edge.startVertex.minDistance  + edge.weight < edge.targetVertex.minDistance :
            return True
        else:
            return False
        
            
    def getShortestPath(self, targetVertex):
        print("Shortest Path to target Vertex is:", targetVertex.minDistance)
        
        node  = targetVertex
        while node is not None:
            print("%s --->" % node.name)
            node = node.predecessor
            
               
            