from flask import Flask, render_template
from flask.globals import request

app = Flask(__name__) # '__main__'

@app.route('/') # new end point
def hello_method():
    return render_template('login.html')

@app.route('/login')
def login_user():
    email= request.form['email'];
    password = request.form['password']
    


if __name__ == "__main__":
    app.run(port = 4500)