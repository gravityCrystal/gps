'''
Created on Jul 3, 2019

@author: ankur.sharma
'''


from MinimumSpanningTree.Prims.edge import Edge
from MinimumSpanningTree.Prims.vertex import Vertex
from MinimumSpanningTree.Prims.algo import Algorithm

vertex1 = Vertex('1') 
vertex2 = Vertex('2')
vertex3 = Vertex('3')
vertex4 = Vertex('4')


edge1 =Edge(1, vertex1, vertex2)
edge2 =Edge(1, vertex1, vertex3)
edge3 =Edge(10, vertex1, vertex4)
edge4 =Edge(1, vertex3, vertex4)


vertex1.adjacentList.append(edge1)
vertex1.adjacentList.append(edge2)
vertex1.adjacentList.append(edge3)
vertex3.adjacentList.append(edge4)


unvisitedList =[]

unvisitedList.append(vertex1)
unvisitedList.append(vertex2)
unvisitedList.append(vertex3)
unvisitedList.append(vertex4)



algo = Algorithm(unvisitedList)
algo.newSpanningTree(vertex1)

