from LinkedList.Node import Node

class LinkedList(object):
    def __init__(self):
        self.head = None
        self.counter = 0
    
        
    def insertAtFirst(self, data):
        self.counter+= 1
        newNodeToInsert = Node(data)
        
        if not self.head: #list is empty
            self.head = newNodeToInsert
        else:# data->next = list->next 
            newNodeToInsert.next = self.head
            self.head = newNodeToInsert
    
    
    def size(self):
        print(self.counter34)
#         return self.counter
    
    
    
    def insertAtLast(self, data):
        actualNode = self.head
        self.counter+= 1
        
        if actualNode is None:
            self.insertAtFirst(data)
            return     
        
        newNodeToInsert= Node(data)
        
        
        while actualNode.next is not None:
            actualNode = actualNode.next
        actualNode.next = newNodeToInsert
    
    def remove(self, dataToRemove):
        if self.head:
            if dataToRemove == self.head.data:
                self.head = self.head.next
            else:
                self.head.removeNode(dataToRemove, self.head)
                
                
    def traverseList(self):
        actualNode = self.head 
        while(actualNode is not None):
            print(actualNode.data)
            actualNode = actualNode.next