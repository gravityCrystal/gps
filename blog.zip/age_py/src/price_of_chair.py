import requests
from bs4 import BeautifulSoup 
request = requests.get("https://erail.in/train-running-status/12626?date=17-Jun-2019&from=NDLS&trycount=1&t=636963786744319692")
content = request.content
soup = BeautifulSoup(content, "html.parser")
element = soup.find("td", {"text":"Next Station"})
print(element.encode('utf8'))