# from post import post
from database import Database
from blog import Blog
from menu import Menu

Database.initalize()
# 
# 
# # 
# post = Post(blog_id ="125",
#             title='Header2',
#             content='Hello Ankur there',
#             author="Ankur Sharma");
             
# # post2 = Post();
# # post3  = Post("10000","title", "content", "author", "6467686", "15/06/2019")

# # print(post.content)

# post.save_to_mongo();
 
# post = post.all_post() 
# post = post.from_mongo('d00e6ffb23664328bf3032e66c99ca34')
# post = Post.from_post("125")
# print(post)


# blog = Blog(author="AnkurS",
#             title="sample title",
#             description= "sample description")
# # 
# blog.new_post()
# blog.save_to_mongo()
# from_db = blog.get_from_mongo('dfdf0cdcbbc64ee793757dc2d7b843fa')
# print(from_db)

# print(blog.get_posts())

# print(blog.get_all_posts())
menu = Menu()
# menu.show_menu()
