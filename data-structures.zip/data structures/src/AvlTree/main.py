class Node(object):
    def __init__(self, data, parentNode):
        self.data = data #intialisation of node objcet for avl tree
        self.parentNode = parentNode
        self.leftChild = None
        self.rightChild = None
        self.balance = 0
    def insert(self, data, parentNode):
        if data < self.data: #check data is less than root
            if not self.leftChild: # left child not present 
                self.leftChild = Node(data, parentNode) # insert at left
            else:
                self.leftChild.insert(data, parentNode) # iterate to next left
        else: 
            if not self.rightChild: #check right child is present or not
                self.rightChild = Node(data, parentNode) # add new right child
            else:
                self.rightChild.insert(data, parentNode) # iterate to next right
        return parentNode # return data
    def traverseOrder(self):
        if self.leftChild:
            self.leftChild.traverseOrder()
        print(self.data)
        if self.rightChild:
            self.rightChild.traverseOrder()
    def getMax(self): # iterate to find max right child of tree
        if not self.rightChild:
            return self.data
        else:
            return self.rightChild.getMax()
    def getMin(self): # iterate to find left most child of the tree
        if not self.leftChild:
            return self.data
        else:
            self.leftChild.getMin()
class AVLTree(object):
    def __init__(self):
        self.rootNode = None # intialiastion
    def insert(self, data): # fuction defination
        parentNode = self.rootNode # make root = parentNode
        if self.rootNode == None: # check root is empty or not
            parentNode = Node(data, None) # create new node
            self.rootNode = parentNode # assign new node to root
        else:
            parentNode = self.rootNode.insert(data, self.rootNode) # iterate to find new root to insert data
        self.rebalanceTree(parentNode) # rebalance tree if required

    def rebalanceTree(self, parentNode): 
        self.setBalance(parentNode) # check and return height difference between left and right child
        if parentNode.balance <= -1:  # if -1 
            if self.height(parentNode.leftChild.leftChild) >= self.height(parentNode.leftChild.rightChild):  
                 # if height of left > right child tree # case 1 rotate right
                parentNode = self.rotateRight(parentNode)
            else:                # rotate first left and right 
                parentNode = self.rotateLeftRight(parentNode) # if height diff > 1 => unbalanced tree => perform rotation  
        elif parentNode.balance > 1:# check height of left and right subtree of right tree
            if self.height(parentNode.rightChild.rightChild) >= self.height(parentNode.rightChild.leftChild):#rotate left
                parentNode = self.rotateLeft(parentNode)
            else: # rotate first right and left
                parentNode = self.rotateRightLeft(parentNode)#  rebalance tree again 
        if parentNode.parentNode is not None:
            self.rebalanceTree(parentNode.parentNode)
        else:            #if balanced make parentNode as root
            self.rootNode = parentNode
    def setBalance(self, node):        # diff between height of right subtree and left tree
        node.balance = (self.height(node.rightChild) - self.height(node.leftChild))
    def height(self, node):
        if node == None:            # if no node found 
            return -1
        else:            # retun max of 1-(-1) height of the tree
            return 1 + max(self.height(node.leftChild), self.height(node.rightChild))
    def rotateLeftRight(self, node):
        print('rotate left to right')        # make new node become left subtree for given node
        node.leftChild = self.rotateLeft(node.leftChild)# rotate right
        return self.rotateRight(node)
    def rotateRightLeft(self, node):
        print('rotate right to left')# rotate right
        node.rightChild = self.rotateRight(node.rightChild)#rotate left
        return self.rotateLeft(node)
    def rotateLeft(self, node):
        print('rotate left')        # assign right subtree to variable B
        b = node.rightChild        # make B parent = node's parent                 # Swapping of node is done
        b.parentNode = node.parentNode        # make node 's right child point to B left child
        node.rightChild = b.leftChild        # check node right child is empty or not    
        if node.rightChild is not None:            # move node right child to become root
            node.rightChild.parentNode = node        # make B left child point to node    
        b.leftChild = node        # node parent point to B
        node.parentNode = b
        if b.parentNode is not None:
            if b.parentNode.rightChild == node:
                b.parentNode.rightChild = b
            else:
                b.parentNode.leftChild = b
        self.setBalance(node)
        self.setBalance(b)
        return b
    def rotateRight(self, node):
        print('rotate right')
        b = node.leftChild
        b.parentNode = node.parentNode
        node.leftChild = b.rightChild
        if node.leftChild is not None:
            node.leftChild.parentNode = node
        b.rightChild = node
        node.parentNode = b
        if b.parentNode is not None:
            if b.parentNode.rightChild == node:
                b.parentNode.rightChild = b
            else:
                b.parentNode.leftChild = b
        self.setBalance(node)
        self.setBalance(b)
        return b
    def traverseInOrder(self):
        self.rootNode.traverseOrder()
tree = AVLTree()
tree.insert(4);print('---')
tree.traverseInOrder()
tree.insert(6);print('---')
tree.traverseInOrder();tree.insert(5);print('---');tree.traverseInOrder();tree.insert(7);print('---');tree.traverseInOrder()