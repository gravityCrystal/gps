class Mymenu(object):
    def __init__(self):
        read_or_write_menu=True
        while read_or_write_menu:
            print("""
            1.Add a Student
            2.Delete a Student
            3.Look Up Student Record
            4.Exit/Quit
            """)
            read_or_write_menu=input("What would you like to do? ")
            if read_or_write_menu=="1":
                print("\nStudent Added")
            elif read_or_write_menu=="2":
                print("\n Student Deleted")
            elif read_or_write_menu=="3":
                print("\n Student Record Found")
            elif read_or_write_menu=="4":
                print("\n Goodbye") 
                read_or_write_menu = None
            else:
                print('Not a menu option')


menu = Mymenu()